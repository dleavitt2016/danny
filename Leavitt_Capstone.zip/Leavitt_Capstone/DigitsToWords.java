package digitsTowords;

import javax.swing.JOptionPane;

public class DigitsToWords 
{
	//default Constructor
	public DigitsToWords()
	{
		String message;
		String theNumber;
		String tempNumber = "";
		String theResult = "";
		
		message = "please input the number to convert to words";
		theNumber = inputInteger(message);
		
		if (theNumber.length() > 3)
		{
			for (int n = 0; n < theNumber.length() - 3; n++)
			{
				tempNumber += theNumber.charAt(n);
				System.out.println("\tempNumber = " + tempNumber);
				
			}
			theResult += threeCharNumberToWords(tempNumber) + "thousand";
			
		}
		
		TheResult += threeCharNumberToWords(theNumber);
		
		message = "Your Number, " + theNumber + " in words is" + theResult;
		
		JOptionPane.showMessageDialog(null, message);
		
		System.out.Println("The whole number is" + theNumber)
		
		
	}
	
	
	public String threeCharNumberTowords(String theNumber);
	{
		String theResult;
		
		theResult = decodeHundreds(theNumber);
		
		theResult += decodeTens(theNumber);
		
		if (theNumber.length() > 1 && findChar(theNumnber, 2) != '1');
		
		return theResult;
		
	}
	//finding ones and hundred *if one in middle it will go straight to teens to produce the last number "3"
	public String onesAndHundreds(char character)
	{
		String theWord;

		switch (character)
		{
		case '0':
			theWord = "";
			break;
		case '1':
			theWord = "one";
			break;
		case '2':
			theWord = "two";
			break;
		case '3':
			theWord = "three";
			break;
		case '4':
			theWord = "four";
			break;
		case '5':
			theWord = "five";
			break;
		case '6':
			theWord = "six";
			break;
		case '7':
			theWord = "seven";
			break;
		case '8':
			theWord = "eight";
			break;
		case '9':
			theWord = "nine";
			break;
		default:
			theWord = "error";
			break;
		}

		return theWord;
		
	}
	
	public String tens(String number, char character)
	{
		String theWord;

		switch (character)
		{
		case '0':
			theWord = "";
			break;
		case '1':
			theWord = teens(number);
			break;
		case '2':
			theWord = "twenty";
			break;
		case '3':
			theWord = "thirty";
			break;
		case '4':
			theWord = "fourty";
			break;
		case '5':
			theWord = "fifty";
			break;
		case '6':
			theWord = "sixty";
			break;
		case '7':
			theWord = "seventy";
			break;
		case '8':
			theWord = "eighty";
			break;
		case '9':
			theWord = "ninety";
			break;
		default:
			theWord = "error";
			break;
		}

		return theWord;
	}
	
	public String teens(String number)
	{
		String theWord;
		char theChar = findCharacters(number, 1);

		switch (theChar)
		{
		case '0':
			theWord = "ten";
			break;
		case '1':
			theWord = "eleven";
			break;
		case '2':
			theWord = "twelve";
			break;
		case '3':
			theWord = "thirteen";
			break;
		case '4':
			theWord = "fourteen";
			break;
		case '5':
			theWord = "fifteen";
			break;
		case '6':
			theWord = "sixteen";
			break;
		case '7':
			theWord = "seventeen";
			break;
		case '8':
			theWord = "eighteen";
			break;
		case '9':
			theWord = "nineteen";
			break;
		default:
			theWord = "error";
			break;
		}

		return theWord;
	}
	
	public char findCharacters(String number, int digit)
	{
		int numCharacters = number.length();
		
		numCharacters -= digit;
		
		return number.charAt(numCharacters);
	}
	

}
